i = 1

while i*i <= 1000:
    print(i*i, end=" ")
    i = i + 1