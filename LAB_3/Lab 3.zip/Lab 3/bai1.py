#bai1a
tong = 0
i = 2000

while i <= 4000:
    if i % 7 == 0 and i % 5 != 0:
        tong = tong + i
    i = i + 1

print("Tong =", tong)
#bai1b
tong = 0
i = 500

while i <= 1000:
    if i % 4 == 0 and i % 6 != 0:
        tong = tong + i
    i = i + 1

print("Tong =", tong)
