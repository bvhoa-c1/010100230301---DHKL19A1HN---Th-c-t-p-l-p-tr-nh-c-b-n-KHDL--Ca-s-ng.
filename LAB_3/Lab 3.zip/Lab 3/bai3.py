n = int(input("Nhap so hang: "))

i = 1
while i <= n:
    j = 1
    while j <= i:
        if j == 1 or j == i or i == n:
            print("*", end="")
        else:
            print(" ", end="")
        j = j + 1
    print()
    i = i + 1