n = int(input("Nhap n: "))
dem = 0

for i in range(1, n+1):
    temp = i
    tong = 0
    
    while temp > 0:
        tong = tong + temp % 10
        temp = temp // 10
    
    if tong % 2 == 0:
        dem = dem + 1

print("So luong =", dem)