n = int(input("Nhap n: "))

a = 0
b = 1

for i in range(n):
    print(b, end=" ")
    temp = a + b
    a = b
    b = temp