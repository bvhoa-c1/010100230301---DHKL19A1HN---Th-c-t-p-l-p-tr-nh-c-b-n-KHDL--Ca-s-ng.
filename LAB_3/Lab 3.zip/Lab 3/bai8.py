n = int(input("Nhap n: "))
max_sum = 0
so_max = 0

for i in range(1, n+1):
    temp = i
    tong = 0
    
    while temp > 0:
        tong = tong + temp % 10
        temp = temp // 10
    
    if tong > max_sum:
        max_sum = tong
        so_max = i

print("So =", so_max)
print("Tong chu so =", max_sum)